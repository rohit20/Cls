package CaseStudyEx;



public class CabBooking {

	private int otp;
	private String pickup;
	private String drop;
	private String mobileNo;
	private String cabType;
	public CabBooking(int otp, String pickup, String drop, String mobileNo,
			String cabType) {
		super();
		this.otp = otp;
		this.pickup = pickup;
		this.drop = drop;
		this.mobileNo = mobileNo;
		this.cabType = cabType;
	}
	public int getOtp() {
		return otp;
	}
	public void setOtp(int otp) {
		this.otp = otp;
	}
	public String getPickup() {
		return pickup;
	}
	public void setPickup(String pickup) {
		this.pickup = pickup;
	}
	public String getDrop() {
		return drop;
	}
	public void setDrop(String drop) {
		this.drop = drop;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	@Override
	public String toString() {
		return new StringBuffer("Otp=" ).append(this.otp).append(" Pick up:").append(this.pickup).append(" Drop:").append(this.drop).append(" MobileNo:").append(this.mobileNo).append(" CabType:").append(this.cabType).toString();
				
	}
}
