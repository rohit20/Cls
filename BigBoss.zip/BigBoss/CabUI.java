package CaseStudyEx;

import java.util.Scanner;

public class CabUI {
	static Scanner sc=new Scanner(System.in);
	static cabFileHelper cabFileHelper=null;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice=0;
		cabFileHelper=new cabFileHelper();
		
		while(true)
		{
			System.out.println("1:Book a Cab \n"+
					"2:Read Cab details From File \n3:Exit");

			System.out.println("\nEnter UR Choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	CabBooking();break;
			case 2: cabFileHelper.display();break;
			default:System.exit(0);			
			}
		}
	}
	private static void CabBooking() 
	{
			 {
		
		System.out.println("Enter otp:");
		String otp=sc.next();
		try 
		{
			if(CabDataValidator.validateotp(otp))
			System.out.println("Enter Pickup:");
			String Pickup=sc.next();
			if(CabDataValidator.validatepickup(Pickup))
			{
				System.out.println("Enter drop ");
				String drop =sc.next();
				if(CabDataValidator.validatedrop(drop))
				{
					System.out.println("Enter mobileNO ");
					String mobileNo =sc.next();
					if(CabDataValidator.validatemobileNo(mobileNo))
					{
						System.out.println("Enter CabType ");
						String CabType =sc.next();
						if(CabDataValidator.validateCabType(CabType))
				
				{
						CabBooking cab=new CabBooking(Integer.parseInt(otp), Pickup , drop, mobileNo,CabType);
						cabFileHelper.CabBooking(cab);
				}	
			}
						
		 } 
		}
		}
		catch (cabException e)
		{			
			System.out.println(e.getMessage());
		}
		
		
}
}
}
