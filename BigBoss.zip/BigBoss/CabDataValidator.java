package CaseStudyEx;

import java.util.regex.Pattern;

public class CabDataValidator {
	public  static  boolean validateotp(String  otp)throws cabException
	{
		String custPattern="\\d{4}";
		if(Pattern.matches(custPattern, otp))
		{
			return true;
		}
		else
		{
			throw new cabException("Otp Should contain only 4 digits. ");
		}
	}
	
	public  static  boolean validatepickup(String pickup)throws cabException
	{
		String custPattern="[A-Za-z]{6,20}";
		if(Pattern.matches(custPattern, pickup))
		{
			return true;
		}
		else
		{
			throw new cabException("pick up should start with CAPITAL & Min 6 and Max 20 characters Allowed");
		}
	}
	
	public  static  boolean validatedrop(String drop)throws cabException
	{
		String custPattern="[A-Za-z]{6,20}";
		if(Pattern.matches(custPattern, drop))
		{
			return true;
		}
		else
		{
			throw new cabException("drop should start with CAPITAL & Min 6 and Max 20 characters Allowed");
		}
	}
	public  static  boolean validatemobileNo(String mobileNo)throws cabException
	{
		String custPattern="[0-9]{10}";
		if(Pattern.matches(custPattern, mobileNo))
		{
			return true;
		}
		else
		{
			throw new cabException("Mobile No should contain only 10 digits");
		}
	}
	public  static  boolean validateCabType(String cabType)throws cabException
	{
		String custPattern="[A-Za-z]{4,20}";
		if(Pattern.matches(custPattern, cabType))
		{
			return true;
		}
		else
		{
			throw new cabException("cab Type should start with CAPITAL & Min 4 and Max 20 characters Allowed");
		}
	}
}
