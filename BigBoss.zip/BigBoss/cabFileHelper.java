package CaseStudyEx;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class cabFileHelper {
	private  static ArrayList<CabBooking> cabList=null;
	static
	{
		cabList=new ArrayList<CabBooking>();
		CabBooking b1=new CabBooking(1010,"Koparkhairane","Airoli","7738720858","Mini");
		CabBooking b2=new CabBooking(1010,"Koparkhairane","Airoli","7738720858","Share");
		CabBooking b3=new CabBooking(1010,"Koparkhairane","Airoli","7738720858","Micro");

		cabList.add(b1);
		cabList.add(b2);
		cabList.add(b3);		

	}
	
public cabFileHelper(){}
	
	public static void CabBooking(CabBooking cab) 
	{			
			cabList.add(cab);				
	}
	
	public static ArrayList<CabBooking> getcabList() {
		return cabList;
	}

	public static void setbookList(ArrayList<CabBooking> cabList) {
		cabFileHelper.cabList = cabList;
	}
	
	public static  void display()
	{
		Iterator<CabBooking> cab=cabList.iterator();
		CabBooking tempcab=null;
		
		while(cab.hasNext())
		{
			tempcab=cab.next();
			System.out.println(tempcab);			
		}
	
	
	}
}
