package CaseStudyEx;

public class cabException extends Exception{
	private static final long serialVersionUID = 1L;
	public cabException()
	{
		super();
	}
	public cabException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public cabException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public cabException(String message) 
	{
		super(message);			
	}
	public cabException(Throwable cause) 
	{
		super(cause);			
	}
}
