package CaseStudyEx;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;



public class ObjectIo {
	private static final String filepath="C:\\Users\\abargode\\Desktop\\Akash Bargode\\Java\\CaseStudy\\bin";

	
		
		
	
	
	private void display(CabBooking serObj) {
		// TODO Auto-generated method stub
		try{
			FileOutputStream fileOut = new FileOutputStream("RideOn.Obj");
			ObjectOutputStream objectOut=new ObjectOutputStream(fileOut);
			objectOut.writeObject(serObj);
			objectOut.close();
			System.out.println("The Object Successfully created");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
