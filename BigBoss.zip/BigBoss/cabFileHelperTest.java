package CaseStudyEx;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class cabFileHelperTest {
	static cabFileHelper collectionHelper;
	static CabBooking book=null;
	
	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new cabFileHelper();
		book =new CabBooking(8888,"Koperkhairane","Aairoliii","7738720858","Micro");		
	}
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		book=null;
	}	
	
	
	@Test 
	public void testAddNewcab() throws cabException
	{
		CabBooking s =new CabBooking(1001,"Sanpada","Dcostata","7738720859","Micro");
		assertEquals(s.getOtp(),1001);
		assertEquals(s.getPickup(),"Sanpada");
		assertEquals(s.getDrop(),"Dcostata");
		assertEquals(s.getMobileNo(),"7738720859");
		assertEquals(s.getCabType(),"Micro");
		
	}
}
